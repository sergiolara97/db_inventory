confi_user='root'
confi_pass='inves'
confi_host='localhost'
confi_database='programa'
 
config_mysql = {'user': confi_user,
            'password': confi_pass,
            'host': confi_host,
            'database': confi_database, }